-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.5.5-10.3.24-MariaDB


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema aghosh_soft_24_7
--

CREATE DATABASE IF NOT EXISTS aghosh_soft_24_7;
USE aghosh_soft_24_7;

--
-- Definition of table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `category_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` (`category_id`,`name`) VALUES 
 (1,'KSEB'),
 (2,'Water Authority'),
 (3,'Police Station'),
 (4,'Food Inspector');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;


--
-- Definition of table `complaint_chat`
--

DROP TABLE IF EXISTS `complaint_chat`;
CREATE TABLE `complaint_chat` (
  `complaint_chat_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `complaint_id` int(10) unsigned NOT NULL,
  `user_query` varchar(45) NOT NULL,
  `department_query` varchar(45) NOT NULL,
  `query_date` varchar(45) NOT NULL,
  `status` varchar(45) NOT NULL,
  `user_id` varchar(45) NOT NULL,
  PRIMARY KEY (`complaint_chat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `complaint_chat`
--

/*!40000 ALTER TABLE `complaint_chat` DISABLE KEYS */;
INSERT INTO `complaint_chat` (`complaint_chat_id`,`complaint_id`,`user_query`,`department_query`,`query_date`,`status`,`user_id`) VALUES 
 (1,4,'Water is not good for useage','Sorry for the mistake','2020-08-14','replied','sam'),
 (2,5,'The Hotel near kadavanthara have old food sto','Thank you for the information','2020-08-14','replied','sam');
/*!40000 ALTER TABLE `complaint_chat` ENABLE KEYS */;


--
-- Definition of table `complaints`
--

DROP TABLE IF EXISTS `complaints`;
CREATE TABLE `complaints` (
  `complaint_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL,
  `user_id` varchar(45) NOT NULL,
  `complaint_date` varchar(45) NOT NULL,
  `complaint_description` varchar(1005) NOT NULL,
  `status` varchar(45) NOT NULL,
  PRIMARY KEY (`complaint_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `complaints`
--

/*!40000 ALTER TABLE `complaints` DISABLE KEYS */;
INSERT INTO `complaints` (`complaint_id`,`category_id`,`user_id`,`complaint_date`,`complaint_description`,`status`) VALUES 
 (4,2,'sam','2020-08-14','Water is not good for useage','pending'),
 (5,4,'sam','2020-08-14','The Hotel near kadavanthara have old food stock ','pending'),
 (6,3,'sam','2020-08-14','accident on m.g road ','pending'),
 (7,1,'sam','2020-08-14','there is no current supply','pending');
/*!40000 ALTER TABLE `complaints` ENABLE KEYS */;


--
-- Definition of table `department`
--

DROP TABLE IF EXISTS `department`;
CREATE TABLE `department` (
  `department_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `address` varchar(45) NOT NULL,
  `phone` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `fax` varchar(45) NOT NULL,
  `user_id` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `category_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`department_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

/*!40000 ALTER TABLE `department` DISABLE KEYS */;
/*!40000 ALTER TABLE `department` ENABLE KEYS */;


--
-- Definition of table `department_pincode`
--

DROP TABLE IF EXISTS `department_pincode`;
CREATE TABLE `department_pincode` (
  `department_pincode_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `department_id` varchar(45) NOT NULL,
  `pincode` varchar(45) NOT NULL,
  `category_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`department_pincode_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department_pincode`
--

/*!40000 ALTER TABLE `department_pincode` DISABLE KEYS */;
/*!40000 ALTER TABLE `department_pincode` ENABLE KEYS */;


--
-- Definition of table `login`
--

DROP TABLE IF EXISTS `login`;
CREATE TABLE `login` (
  `user_id` varchar(20) NOT NULL,
  `password` varchar(45) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `login`
--

/*!40000 ALTER TABLE `login` DISABLE KEYS */;
/*!40000 ALTER TABLE `login` ENABLE KEYS */;


--
-- Definition of table `user_register`
--

DROP TABLE IF EXISTS `user_register`;
CREATE TABLE `user_register` (
  `user_id` varchar(20) NOT NULL,
  `name` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `phone` varchar(45) NOT NULL,
  `pincode` varchar(45) NOT NULL,
  `password` varchar(1000) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_register`
--

/*!40000 ALTER TABLE `user_register` DISABLE KEYS */;
INSERT INTO `user_register` (`user_id`,`name`,`email`,`phone`,`pincode`,`password`) VALUES 
 ('sam','sam joy','sam123@gmail.com','9632587415','369852','sam');
/*!40000 ALTER TABLE `user_register` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
