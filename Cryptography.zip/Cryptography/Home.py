from doctest import debug
from flask import Flask, render_template, request, session, redirect, flash
from flask.sessions import SecureCookieSession
from DBConnection import Db
from datetime import datetime
import requests

app = Flask(__name__, template_folder='template', static_url_path='/static/')

app.secret_key = "asdff"


@app.route('/')
def ind():
    return render_template("HomePage.html")
@app.route('/HomePage')
def homePage():
    return render_template("HomePage.html")

@app.route('/l')
def login():
    return render_template("login.html")
@app.route('/login')
def log():
    return render_template("login.html")

@app.route('/Departmenthome')
def Departmenthome():
    return render_template("/Departmenthome.html")


@app.route('/adminhome')
def Adminhome():
    return render_template("/AdminHome.html")
@app.route('/LogOut')
def logout():
    return render_template("/LogOut.html")



@app.route('/login1', methods=['post'])
def login1():
    name = request.form['un']
    password = request.form['pass']
    session['lid'] = name
    qry = "select * from login where user_id='" + name + "' and password='" + password + "'"
    ob = Db()
    print(qry)
    res = ob.selectOne(qry)
    if res is not None:
        return Adminhome()

    qr = "select department_id from department where user_id='" + name + "' and password='" + password + "'"
    ob = Db()
    print(qr)
    res = ob.selectOne(qr)
    if res is not None:
        deptid = res['department_id']
        session['deptid'] = deptid
        return Departmenthome()
    else:
        return "<script>alert('Invalid');window.location='/';</script>"


# -----------------------------------ADMIN Monitoring---------------------------------------#
@app.route('/Link_Add_Category')
def AddCategory():
    return render_template("Monitoring/AddCategory.html")


@app.route('/Category', methods=['post'])
def AddCat():
    name = request.form['TxtCategoryName']
    ob = Db()
    data = None
    res = ob.selectOne("select * from category where name='" + name + "'")
    if res:
        data = res
    if data == None:
        ob = Db()
        q = "insert into category values(null,'" + name + "')"
        ob.insert(q)
        return "<script>alert('Category Inserted Succefully');window.location='/adminhome';</script>"
    return "<script>alert('Category Already exist');window.location='/Link_Add_Category';</script>"

@app.route('/View_Category')
def ViewCategory():
    ob = Db()
    data = None
    res = ob.select("select * from category")
    if res:
        data = res
        if data == None:
            return render_template("Monitoring/NoDataFound.html")
        return render_template("Monitoring/ViewCategory.html", data=res)


@app.route('/View_Depart_Based_Complaints')
def ViewDepartComplaints():
    ob = Db()
    data = None
    res = ob.select("select * from category")

    if res:
        data = res
        if data == None:
            return render_template("Monitoring/NoDataFound.html")
        return render_template("Monitoring/ViewCategoryC.html", data=res)


@app.route('/Link_Add_Department')
def AddDepartment():
    id = request.args.get('id')
    session['id'] = id

    return render_template("Monitoring/AddDepartment.html")


@app.route('/Department', methods=['post'])
def department():
    name = request.form['TxtName']
    address = request.form['TxtAddress']
    phone = request.form['TxtPhone']
    email = request.form['TxtEmail']
    fax = request.form['TxtFax']
    userid = request.form['TxtUserid']
    password = request.form['TxtPassword']
    categoryid = session['id']
    ob = Db()
    q = "insert into department values(null,'" + name + "','" + address + "','" + phone + "','" + email + "','" + fax + "','" + userid + "','" + password + "','" + str(
        categoryid) + "')"
    ob.insert(q)
    return Adminhome()


@app.route('/View_Department')
def ViewDepart():
    id = request.args.get('id')
    session['catid'] = id
    ob = Db()
    data = None
    res = ob.select("select * from department where category_id='" + str(id) + "'")
    print(res)
    if res:
        data = res
        if data==None:
            return render_template("Monitoring/NoDataFound.html")
    return render_template("Monitoring/ViewDepartment.html", data=res)


@app.route('/Link_Assign_Pincode')
def mark():
    did = request.args.get('id')
    session['departid'] = did
    return render_template("Monitoring/Assign_pincode.html")


@app.route('/Pincode', methods=['post'])
def assignpincode():
    departid = session['departid']
    pincode = request.form['TxtPincode']
    categoryid = session['catid']
    ob = Db()
    q = "insert into department_pincode values(null,'" + str(departid) + "','" + pincode + "','" + str(
        categoryid) + "')"
    ob.insert(q)
    return Adminhome()


@app.route('/View_Assign_Pincode')
def ViewPincode():
    id = request.args.get('id')
    ob = Db()
    data = None
    res = ob.select("select * from department_pincode where department_id='" + str(id) + "'")
    if res:
        data = res
    if data == None:
        return render_template("Monitoring/NoDataFound.html")
    return render_template("Monitoring/ViewAssignPincode.html", data=res)


@app.route('/Link_Pincode_Upd')
def EditPincode():
    id = request.args.get('id')
    db = Db()
    res = db.selectOne("select * from department_pincode where department_pincode_id='" + str(id) + "'")
    return render_template("Monitoring/SelectPincode.html", data=res, vid=str(id))


@app.route('/UpdatePincode/', methods=['post'])
def updPincode():
    departid = request.form['id']
    pincode = request.form['TxtPincode']
    ob = Db()
    es = ob.update("update department_pincode set pincode='" + pincode + "' where department_pincode_id='" + str(departid) + "'")
    return ViewCategory()


@app.route('/Pincode_Delete')
def DeletePincode():
    id = request.args.get('id')
    db = Db()
    res = db.delete("delete from department_pincode where department_pincode_id='" + str(id) + "'")
    return ViewCategory()


@app.route('/Link_upd_Depart')
def editdepartment():
    id = request.args.get('id')
    db = Db()
    res = db.selectOne("select * from department where department_id='" + str(id) + "'")
    return render_template("Monitoring/SelectDepartment.html", data=res, vid=str(id))


@app.route('/UpdateDepart/', methods=['post'])
def updDepart():
    departid = request.form['id']
    name = request.form['TxtName']
    address = request.form['TxtAddress']
    phone = request.form['TxtPhone']
    email = request.form['TxtEmail']
    fax = request.form['TxtFax']
    userid = request.form['TxtUserid']
    password = request.form['TxtPassword']
    ob = Db()
    es = ob.update(
        "update department set name='" + name + "',address='" + address + "',phone='" + phone + "',email='" + email + "',fax='" + fax + "',user_id='" + userid + "',password='" + password + "' where department_id='" + str(
            departid) + "'")
    return ViewCategory()


@app.route('/Link_Dele_Depart')
def departdele():
    id = request.args.get('id')
    db = Db()
    res = db.delete("delete from department where department_id='" + str(id) + "'")
    return ViewCategory()


@app.route('/Link_Complaints')
def DepartmentComplaints():
    id = request.args.get('id')
    data=None
    db = Db()
    res = db.select("select complaint_date,category_id from complaints where category_id='"+str(id)+"'")
    if res:
        data = res
    if data == None:
            return render_template("Monitoring/NoDataFound.html")
    return render_template("Monitoring/Date.html", data=res)


@app.route('/Department_Complaints')
def DepartCompl():
    id = request.args.get('id')
    date = request.args.get('date')
    data=None
    db = Db()
    res = db.select("select com.*,bs.name from complaints as com join branch_staff as bs on com.branch_staff_id=bs.branch_staff_id where com.category_id='" + str(id) + "' and com.complaint_date='" + str(date) + "'")
    if res:
        data = res
    if data == None:
        return render_template("Monitoring/NoDataFound.html")
    return render_template("Monitoring/DepartmentComplaint.html", data=res)

@app.route('/Link_chat')
def chat():
    id = request.args.get('id')
    db = Db()
    data = None
    res = db.select("select * from complaint_chat where complaint_id='" + str(id) + "'")
    if res:
        data = res
        print(res)
    if data == None:
        return render_template("Monitoring/NoDataFound.html")
    return render_template("Monitoring/ComplaintChat.html", data=res)
@app.route('/View_Complaint_Count')
def Count():
    id = request.args.get('id')
    data=None
    db = Db()
    res = db.select("select * from category")
    if res:
        data = res
    if data == None:
        return render_template("Monitoring/NoDataFound.html")
    return render_template("Monitoring/CatCount.html", data=res)


@app.route('/ComCount')
def comcount():
    id = request.args.get('id')
    name = request.args.get('name')
    data=None
    db = Db()
    res = db.select("select count(complaint_id) as comp from complaints where category_id='" + str(id) + "'")
    if res:
        data = res
    if data == None:
        return render_template("Monitoring/NoDataFound.html")
    return render_template("Monitoring/CountCat.html", data=res)


@app.route('/Link_Send_Notification')
def category():
    db = Db()
    data=None
    res = db.select("select * from category")
    if res:
        data = res
    if data == None:
            return render_template("Monitoring/NoDataFound.html")
    return render_template("Monitoring/Category.html", data=res)


@app.route('/View_Department_N')
def departmentNotify():
    id = request.args.get('id')
    session['catid'] = id
    data=None
    db = Db()
    res = db.select("select * from department where category_id='" + str(id) + "'")
    if res:
        data = res
    if data == None:
        return render_template("Monitoring/NoDataFound.html")
    return render_template("Monitoring/Department.html", data=res)


@app.route('/LinkSendNotification')
def NotificationSend():
    id = request.args.get('id')
    session['did'] = id
    return render_template("Monitoring/Notification.html")


@app.route('/Notification', methods=['post'])
def notification():
    notific = request.form['TxtNotification']
    categoryid = session['catid']
    departmentid = session['did']
    q = "insert into notification values(null,'" + notific + "',curdate(),'" + str(categoryid) + "','" + str(
        departmentid) + "')"
    ob = Db()
    ob.insert(q)
    return Adminhome()


@app.route('/Link_View_Notification')
def ViewNotification():
    data=None
    db = Db()
    res = db.select("select n.notification_id,n.notification,n.notification_date,c.name,d.name as dname from notification as n join category as c join department as d on n.category_id=c.category_id and n.department_id=d.department_id and d.category_id=c.category_id")
    if res:
        data = res
    if data == None:
            return render_template("Monitoring/NoDataFound.html")
    return render_template("Monitoring/ViewNotification.html", data=res)
@app.route('/Link_Search_Complaints')
def link_search_complaints():
    return render_template("Monitoring/search_Complaints.html")
@app.route('/SearchComplaintsUser',methods=['post'])
def searchComplaintuser():
    userid = request.form['Txtuserid']
    data = None
    db = Db()
    res = db.select("select * from complaints where user_id='" + str(userid) + "'")
    if res:
        data = res
    if data == None:
        return render_template("Monitoring/NoDataFound.html")
    return render_template("Monitoring/SearchUserComplaint.html", data=res)
@app.route('/LinkEditCategory')
def linkEditCategory():
    id = request.args.get('id')
    db = Db()
    data = None
    res = db.selectOne("select * from category where category_id='"+id+"' ")
    if res:
        data = res
    if data == None:
        return render_template("Monitoring/NoDataFound.html")
    return render_template("Monitoring/EditCategory.html", data=res)
@app.route('/UpdateCategory',methods=['post'])
def updateCategory():
    id = request.form['id']
    category = request.form['TxtCategory']
    ob = Db()
    data = None
    res = ob.selectOne("select * from category where name='" + category + "'")
    if res:
        data = res
    if data == None:
        ob = Db()
        es = ob.update("update category set name='" + category + "' where category_id='" + id + "'")
        return "<script>alert('Category Updated Successfully');window.location='/ViewCategory';</script>"
    return "<script>alert('Category Already Exist');window.location='/ViewCategory';</script>"
@app.route('/DeleteCategory')
def deleteCategory():
    id = request.args.get('id')
    ob = Db()
    es = ob.delete("delete from category where category_id='" + id + "'")
    return "<script>alert('Category Deleted Successfully');window.location='/ViewCategory';</script>"

# -----------------------------------Department Process---------------------------------------#


@app.route('/View_complaintsD')
def ViewCompD():
    userid = session['lid']
    db = Db()
    data = None
    res = db.select("SELECT com.*,bs.name from complaints as com join department_pincode as dp join department as d join branch_staff as bs on com.pincode=dp.pincode and dp.department_id=d.department_id and com.category_id=dp.category_id and com.branch_staff_id=bs.branch_staff_id where d.user_id='"+str(userid)+"'")
    if res:
        data = res
    if data == None:
        return render_template("Process/NoDataFound.html")
    return render_template("Process/ViewCompD.html", data=res)


@app.route('/ReplyComplaint')
def ComplaintReply():
    id = request.args.get('id')
    session['compid'] = id
    return render_template("Process/ComplaintReply.html")


@app.route('/ReplyCom', methods=['post'])
def ReplyCom():
    comid = session['compid']
    reply = request.form['TxtReply']
    ob = Db()
    q = "update complaints set reply='" + reply + "',status='replied' where complaint_id='" + str(comid) + "'"
    ob.update(q)
    return Departmenthome()


@app.route("/View_complaintsDate")
def complaintsDate():
    userid = session['lid']
    data=None
    db = Db()
    res = db.select("SELECT complaint_date from complaints as com join department_pincode as dp join department as d on com.pincode=dp.pincode and dp.department_id=d.department_id and com.category_id=dp.category_id where d.user_id='"+str(userid)+"'")
    if res:
        data = res
    if data == None:
            return render_template("Process/NoDataFound.html")
    return render_template("Process/DateD.html", data=res)


@app.route("/Department_Com_Date")
def Department_Com_Date():
    userid = session['lid']
    date = request.args.get('date')
    data=None
    db = Db()
    res = db.select("SELECT com.*,bs.name from complaints as com join department_pincode as dp join department as d join branch_staff as bs on com.pincode=dp.pincode and dp.department_id=d.department_id and com.category_id=dp.category_id and bs.branch_staff_id=com.branch_staff_id where d.user_id='" + str(userid) + "' and com.complaint_date='" + str(date) + "'")
    if res:
        data = res
    if data == None:
            return render_template("Process/NoDataFound.html")
    return render_template("Process/ComplaintDepart.html", data=res)


@app.route("/Link_DepartChat")
def DepartChat():
    id = request.args.get('id')
    data = None
    db = Db()
    res = db.select("select * from complaint_chat where complaint_id='" + str(id) + "'")
    if res:
        data = res

    if data == None:
            return render_template("Process/NoDataFound.html")
    return render_template("Process/DComplaintChat.html", data=res)


@app.route("/Viewmorechat")
def MoreChat():
    id = request.args.get('id')
    data=None
    db = Db()
    res = db.select("select * from complaint_chat where complaint_id='" + str(id) + "'")
    if res:
        data = res
    if data == None:
            return render_template("Process/NoDataFound.html")
    return render_template("Process/MoreChat.html", data=res)


@app.route("/ReplyComplaintChat")
def ReplyChat():
    id = request.args.get('id')
    session['compid'] = id
    return render_template("Process/ComplaintChatReply.html")


@app.route("/ReplyChatCom", methods=['post'])
def ReplyComplaintChat():
    comid = session['compid']
    reply = request.form['TxtReply']
    ob = Db()
    q = "update complaint_chat set department_query='" + reply + "',status='replied' where complaint_chat_id='" + str(
        comid) + "'"
    ob.update(q)
    return ViewCompD()


@app.route("/View_complaint_Pincode")
def LinkSearchPincode():
    return render_template("Process/SearchPincode.html")


@app.route("/Search_Pin", methods=['post'])
def pinsearch():
    userid = session['lid']
    pincode = request.form['TxtPin']
    data=None
    ob = Db()
    res = ob.select( "SELECT com.*,bs.name from complaints as com join  department as d join branch_staff as bs on d.category_id=com.category_id and com.branch_staff_id=bs.branch_staff_id where d.user_id='" + str(
            userid) + "' and com.pincode='" + str(pincode) + "'")
    if res:
        data = res
    if data == None:
        return render_template("Process/NoDataFound.html")
    return render_template("Process/Pincode.html", data=res)


@app.route('/View_Notification_D')
def ViewNotificationD():
    userid = session['lid']
    data=None
    db = Db()
    res = db.select("SELECT n.* from notification as n join department as d on n.department_id=d.department_id where d.user_id='" + str(userid) + "'")
    if res:
        data = res
    if data == None:
        return render_template("Process/NoDataFound.html")
    return render_template("Process/ViewNotificationD.html", data=res)

@app.route('/LinkAddStaff')
def linkAddStaff():
    return render_template("Process/AddStaff.html")
@app.route('/AddStaff',methods=['post'])
def addStaff():
    bsid=request.form['TxtBranchStaffId']
    name= request.form['TxtName']
    phone = request.form['TxtPhone']
    email= request.form['TxtEmail']
    departmentid = str(session['deptid'])
    print(departmentid)
    ob = Db()
    data = None
    res = ob.selectOne("select * from branch_staff where branch_staff_id='" + bsid + "' or email='"+email+"'")
    if res:
        data = res
    if data == None:
        ob = Db()
        q = "insert into branch_staff values('" + bsid + "','" + name + "','" + phone + "','" + email + "'," + departmentid + ")"
        ob.insert(q)
        return "<script>alert('Staff Inserted Successfully');window.location='/Departmenthome';</script>"
    return "<script>alert('Details Already Exist');window.location='/LinkAddStaff';</script>"

@app.route('/Viewstaff')
def viewStaff():
    departmentid = str(session['deptid'])
    data = None
    db = Db()
    res = db.select("select * from branch_staff where department_id='"+departmentid+"' ")
    if res:
        data = res
    if data == None:
        return render_template("Process/NoDataFound.html")
    return render_template("Process/ViewStaff.html", data=res)
@app.route('/DeleStaff')
def deleStaff():
    id = request.args.get('id')
    ob = Db()
    q = "delete from branch_staff where branch_staff_id='"+id+"'"
    ob.delete(q)
    return "<script>alert('Staff Deleted Successfully');window.location='/Departmenthome';</script>"
if __name__ == '__main__':
    app.run(debug=True)
